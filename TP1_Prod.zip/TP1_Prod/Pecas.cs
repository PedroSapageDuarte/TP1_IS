﻿using System;

namespace TP1_Prod
{
    public class Pecas
    {
        //Código da peça: 8 caracteres (ex: "aa123456")
        public string CodigoPeca { get; set; }

        //Data de produção (formato yyyy-MM-dd)
        public DateTime DataProducao { get; set; }

        //Hora de produção (formato HH:mm:ss)
        public TimeSpan HoraProducao { get; set; }

        //Tempo de produção (em segundos)
        public int TempoProducao { get; set; }

        //Código do resultado do teste (deve ter 2 dígitos, ex: "01", "02", etc.)
        public string CodigoResultado { get; set; }

        //Data em que o teste foi realizado (opcional)
        public DateTime? DataTeste { get; set; }
    }
}
