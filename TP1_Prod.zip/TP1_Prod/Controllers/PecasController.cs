﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System;
using System.Data;
using TP1_Prod;

namespace TP1_Prod.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProducaoController : ControllerBase
    {
        //Connection String da DB
        string sqlConnectionString = "Data Source=localhost\\SQLEXPRESS01;Initial Catalog=Producao; Integrated Security=True; Connect Timeout = 30; Encrypt=False; TrustServerCertificate=False; ApplicationIntent=ReadWrite; MultiSubnetFailover=False";

        // POST api/Producao
        [HttpPost]
        public IActionResult Post([FromBody] Pecas pecas)
        {
            try
            {
                using(SqlConnection con = new SqlConnection(sqlConnectionString))
                {
                    //A usar o Stored Procedure para Inserir as Peças
                    using(SqlCommand cmd = new SqlCommand("SP_InserirPecas", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        //Adiciona os parâmetros necessários para o funcinamento da stored procedure de inserção
                        cmd.Parameters.AddWithValue("@CodigoPeca", pecas.CodigoPeca);
                        cmd.Parameters.AddWithValue("@DataProducao", pecas.DataProducao);
                        cmd.Parameters.AddWithValue("@HoraProducao", pecas.HoraProducao);
                        cmd.Parameters.AddWithValue("@TempoProducao", pecas.TempoProducao);

                        //Se o código do teste de uma peça não existir, passa a ser "06 - Desconhecido"
                        if(string.IsNullOrEmpty(pecas.CodigoResultado))
                            cmd.Parameters.AddWithValue("@CodigoResultado", "06");
                        else
                            cmd.Parameters.AddWithValue("@CodigoResultado", pecas.CodigoResultado);

                        //A tabela testes exige a data do teste, algo que a legacy app não fornece
                        if(pecas.DataTeste == null)
                            cmd.Parameters.AddWithValue("@DataTeste", DateTime.Now.Date);
                        else
                            cmd.Parameters.AddWithValue("@DataTeste", pecas.DataTeste.Value.Date);

                        //Abrir conexão com a BD
                        con.Open();

                        var resultado = cmd.ExecuteScalar();  //Se a SP retorna o ID inserido

                        //Fechar conexão com a BD
                        con.Close();

                        //Print do resultado
                        return Ok(new { ProdutoID = resultado, Mensagem = "Inserção realizada com sucesso." });
                    }
                }
            }
            catch (SqlException ex)
            {
                return BadRequest(new { Erro = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Erro = ex.Message });
            }
        }

        // PUT api/Producao/{id}
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Pecas pecas)
        {
            try
            {
                using(SqlConnection con = new SqlConnection(sqlConnectionString))
                {
                    //A usar o Stored Procedure para Atualizar as Peças
                    using(SqlCommand cmd = new SqlCommand("SP_AtualizarProduto", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        //Parâmetros necessários para a atualização
                        cmd.Parameters.AddWithValue("@ID_Produto", id);
                        cmd.Parameters.AddWithValue("@CodigoPeca", pecas.CodigoPeca);
                        cmd.Parameters.AddWithValue("@DataProducao", pecas.DataProducao);
                        cmd.Parameters.AddWithValue("@HoraProducao", pecas.HoraProducao);
                        cmd.Parameters.AddWithValue("@TempoProducao", pecas.TempoProducao);
                        cmd.Parameters.AddWithValue("@CodigoResultado", pecas.CodigoResultado);
                        cmd.Parameters.AddWithValue("@DataTeste", pecas.DataTeste);

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();

                        return Ok(new { Mensagem = "Produto atualizado com sucesso." });
                    }
                }
            }
            catch (SqlException ex)
            {
                return BadRequest(new { Erro = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Erro = ex.Message });
            }
        }

        // DELETE api/Producao/{id}
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                using(SqlConnection con = new SqlConnection(sqlConnectionString))
                {
                    //A usar o Stored Procedure para Remover as Peças
                    using(SqlCommand cmd = new SqlCommand("SP_RemoveProduto", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        //Passa apenas o ID do produto a ser removido
                        cmd.Parameters.AddWithValue("@ID_Produto", id);

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();

                        return Ok(new { Mensagem = "Produto removido com sucesso." });
                    }
                }
            }
            catch (SqlException ex)
            {
                return BadRequest(new { Erro = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Erro = ex.Message });
            }
        }
    }
}
